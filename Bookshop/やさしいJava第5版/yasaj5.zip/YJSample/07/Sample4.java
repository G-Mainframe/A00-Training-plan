class Sample4
{
   public static void main(String[] args)
   {
      int[] test = {80,60,22,50,75};

      for(int i=0; i<5; i++){
         System.out.println((i+1) + "�Ԗڂ̐l�̓_����" + test[i] + "�ł��B");
     }
   }
}
