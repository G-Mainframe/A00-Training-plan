import java.applet.Applet;
import java.awt.Graphics;

public class Sample2 extends Applet
{
   public void paint(Graphics g)
   {
      g.drawLine(10, 10, 100, 100);
   }
}
