class SampleP5_1
{
   public static void main (String[] args)
   {
      System.out.println(06);
      System.out.println(024);
      System.out.println(015);
   }
}
