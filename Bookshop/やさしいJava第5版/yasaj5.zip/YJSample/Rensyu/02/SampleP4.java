class SampleP4
{
   public static void main(String[] args)
   {
      System.out.println("1\t2\t3\t");
   }
}

