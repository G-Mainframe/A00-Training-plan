import java.applet.Applet;
import java.awt.Graphics;

public class SampleP2 extends Applet
{
   public void paint(Graphics g)
   {
      g.fillRect(10, 10, 100, 100);
   }
}
