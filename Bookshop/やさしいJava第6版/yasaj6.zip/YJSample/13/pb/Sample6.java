package pb;
import pc.Car;

class Sample6
{
   public static void main(String args[])
   {
      Car car1 = new Car();
      car1.show();
   }
}
