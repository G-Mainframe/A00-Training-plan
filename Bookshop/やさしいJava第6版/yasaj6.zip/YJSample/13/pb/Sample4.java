package pb;

class Sample4
{
   public static void main(String args[])
   {
      Car car1 = new Car();
      car1.show();
   }
}
