package pa;

class Sample3
{
   public static void main(String args[])
   {
      Car car1 = new Car();
      car1.show();
   }
}
