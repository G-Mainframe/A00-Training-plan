class Sample3
{
   public static void main(String[] args)
   {
      System.out.println('A');
      System.out.println("�悤����Java�ցI");
      System.out.println(123);
   }
}
