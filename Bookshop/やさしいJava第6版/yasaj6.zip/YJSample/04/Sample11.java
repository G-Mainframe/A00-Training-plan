class Sample11
{
   public static void main(String[] args)
   {
      int num1 = 5;
      int num2 = 4;

      double div = (double)num1 / (double) num2;
      
      System.out.println("5/4��" + div + "�ł��B");
   }
}
