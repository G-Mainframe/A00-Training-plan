﻿using System;

class Sample1
{
    public static void Main()
    {
        //画面に文字を出力する
        Console.WriteLine("ようこそC#へ!");
        Console.WriteLine("C#をはじめましょう!");
    }
}   