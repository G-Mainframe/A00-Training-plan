﻿using System.Windows.Forms;

class Sample2
{
    public static void Main()
    {
        Form fm;
        fm = new Form();

        fm.Text = "ようこそC#へ!";

        Application.Run(fm);
    }
}
