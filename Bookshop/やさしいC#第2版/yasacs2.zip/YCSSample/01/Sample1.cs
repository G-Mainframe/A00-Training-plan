﻿using System;

class Sample1
{
    public static void Main()
    {
        Console.WriteLine("ようこそC#へ!");
    }
}   